<template>
	<div class="content">
	    <div class="left">
	        <div class="sideBar">
	            <div class="hd">
	                <em>全部书籍</em>
	            </div>
	            <div class="books-list" v-for="obj in arrBooks" :key="obj.id">
	                <h3>{{obj.title}}</h3>
	                <ul>
	                    <li v-for="book in obj.books" :key="book.id">
	                        <a href="#">{{ book.name }}</a>
	                    </li>
	                </ul>
	            </div>
	        </div>
	    </div>
	<!-- right -->
	    <div class="right">
	        <div class="banner">
	            <img src="../assets/img/banner01.png" alt="">
	        </div>
	        <div class="products" v-for="items in products" :key="items.id">
	            <div class="imgBox">
	                <img :src="items.src" alt="">
	            </div>
	            <div class="info">
	                <h3>{{items.title}}</h3>
	                <p>{{items.info}}</p>
	                <div class="btn">
	                    <router-link to="/detail">立即购买</router-link>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				arrBooks: [
					{	
						id:10,
						title:'开发专业书籍',
						books:[
							{name:'Web标准网站设计之道'},
							{name:'Photoshop商业网站设计'},
							{name:'C#编程基础'},
							{name:'SQL Server数据库基础'}
						]
					},
					{
						id:11,
						title:'应用专业书籍',
						books:[
							{name:'计算机基础应用'},
							{name:'Linux系统管理'},
							{name:'Windows网络服务管理'},
							{name:'Windows活动目录管理'},
							{name:'Windows系统管理'}
						]
					}
				],
				products:[
					{
						id:10,
						title:'移动互联网开发全套书籍',
						info:'高端专业独享教材,突破传统教与学,合理利用碎片化学习时间。',
						src:require('../assets/img/1.png')
						// export / import  =====>  JS的ES6语法
						// require ====>  Common.js语法（nodejs）
					},
					{
						id:11,
						title:'移动互联网应用专业书籍',
						info:'高端专业独享教材,突破传统教与学,合理利用碎片化学习时间。',
						src:require('../assets/img/2.png')
					},
					{
						id:12,
						title:'人工智能专业书籍',
						info:'高端专业独享教材,突破传统教与学,合理利用碎片化学习时间。',
						src:require('../assets/img/3.png')
					},
					{
						id:13,
						title:'大数据专业书籍',
						info:'高端专业独享教材,突破传统教与学,合理利用碎片化学习时间。',
						src:require('../assets/img/4.png')
					}
				]
			}
		},
	}
</script>

<style>
</style>
