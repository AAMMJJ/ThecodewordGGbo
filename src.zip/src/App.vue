<template>
  <div id="app">
		<div class="container">
		        <div class="header">
		            <div class="logo">
		                <router-link to="/">
							<img src="./assets/img/logo.png">
						</router-link>
		            </div>
		            <div class="min-nav">
		                <a href="#">登录</a> |
		                <a href="#">注册</a> |
		                <a href="#">关于</a>
		            </div>
		        </div>
		    </div>
		    <!-- 正文 -->
			<router-view></router-view>
		    <!-- footer -->
		    <div class="footer">
		        <p>Copyright © 2017 武汉格莱科技 保留公司所有权利。</p>
		    </div>
  </div>
</template>


<!-- 
 Vue -cli     vue create myapp   cli=> 基于 webpack（打包器）构建的
 //  webpack 底层 node.js
 -->
<style lang="scss">
@import './assets/css/style.css'
</style>
